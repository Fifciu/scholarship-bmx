<?php
    /*
    * Template Name: Portfolio Item
    */
    get_header();

?>

<div class="full-width-container single-portfolio main-content-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- page content -->
                <?php if ( have_posts() ) : ?>
                    <?php while ( have_posts() ) : the_post(); ?>
                        <div class="text-center">
                            <h1><?php the_title(); ?></h1>
                            <?php if ( has_excerpt() ) : ?>
                                <div class="portfolio-intro">
                                    <?php the_excerpt(); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if ( has_post_thumbnail( $post->ID ) ) : ?>
                            <div class="featured-image single-portfolio-featured-image">
                                <?php echo get_the_post_thumbnail( $post->ID, 'themeora-thumbnail-span-12' ); ?>
                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="post-content">
                                    <?php the_content(); ?>
                                </div>
                                <?php themeora_jetpack_shares(); ?>
                            </div>
                        </div>

                    <?php endwhile; ?>

                    <?php if ( is_active_sidebar( 'Portfolio widget' ) ) : ?>
                        <div class="row">
                            <div id="widget-area" class="portfolio-bottom-widget widget-area col-md-6 col-md-offset-3">
                                <?php dynamic_sidebar( 'Portfolio widget' ); ?>
                            </div><!-- .widget-area -->
                        </div>
                    <?php endif; ?>

                    <?php if ( get_theme_mod( 'themeora_portfolio_related', 'yes' ) === 'yes' ) : ?>

                        <div class="related-work">
                            <div class="row">
                                <?php
                                $args = array(
                                    'post_type' => 'page',
                                    'meta_key' => '_wp_page_template',
                                    'meta_value' => 'template-portfolio-item.php',
                                    'post_status' => 'publish',
                                    'posts_per_page' => 3,
                                    'orderby' => 'menu_order',
                                    'order' => 'DESC',
                                    'post__not_in' => array($post->ID) //exclude current post
                                );

                                $wp_query = new WP_Query( $args );
                                //set the grid based on theme options
                                $gridClass = 'col-md-4 col-sm-4';
                                $img_size = 'themeora-portfolio-span-8';
                                ?>

                                <?php if ( $wp_query->have_posts() ) : ?>
                                    <h2 class="col-md-12 text-center"><?php _e('More', 'oren') ?></h2>
                                    <?php while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>
                                        <div class="<?php echo $gridClass; ?> col-xs-12">
                                            <?php if ( has_post_thumbnail( $wp_query->post->ID )) : ?>
                                                <div class="portfolio-item">
                                                    <a class="portfolio-link" href="<?php echo the_permalink(); ?>">
                                                        <?php
                                                        $previewImage = wp_get_attachment_image_src( get_post_thumbnail_id( $wp_query->post->ID ), $img_size );
                                                        ?>
                                                        <img src="<?php echo $previewImage[0]; ?>" alt="" />
                                                        <div class="portfolio-details">
                                                            <div class="details-text">
                                                                <h2><?php the_title(); ?></h2>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endwhile; ?>
                                    <?php wp_reset_query(); ?>
                                <?php endif; ?>
                            </div><!-- end row -->
                        </div><!-- end related-work -->
                    <?php endif; ?>
                <?php endif; //have-posts ?>
            </div>

        </div><!-- end row -->
    </div><!-- end Container -->
</div><!-- end full-width-container -->


<?php get_footer(); ?>