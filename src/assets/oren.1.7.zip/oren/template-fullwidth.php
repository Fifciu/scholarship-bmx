<?php
/*
 * Template Name: Full Width
*/
get_header();
// Get theme options
$enable_parallax = get_theme_mod('themeora_enable_parallax', 'yes');
$parallax_settings = '';
if ( 'yes' === $enable_parallax ){
    //advanced users can change this line to change the parallax effect. For documentation check https://github.com/Prinzhorn/skrollr
    $parallax_settings = 'data-center="background-position: 50% 50%;"
    data-top-bottom="background-position: 50% 20%;"';
}
// Get the featured image to set as the background of the header. Use header_image if set, featured image if not
$background_image = '';
if ( wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full-size' ) ) {
    $background_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full-size' );
    $background_image = $background_image[0];
}
if ( get_header_image() ) {
    $background_image = get_header_image();
}
?>

<header <?php echo $parallax_settings; ?> class="full-width-container center-page welcome-screen <?php $background_image != '' ? print 'header-with-background' : '' ?> <?php has_excerpt() ? print 'header-with-excerpt ' : print 'header-without-excerpt'; ?> " role="banner" data-welcome-background="<?php echo $background_image; ?>" >
    <div class="container">
        <h1 class="title"><span><?php the_title(); ?></span></h1>
        <?php if ( has_excerpt() ) {
            the_excerpt(); 
        }
        ?>
    </div>
</header>

<div class="full-width-container main-content-area">
    
    <div class="container content">    
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <?php the_content(); ?>
            <?php endwhile; ?>
            <?php themeora_jetpack_shares(); ?>
        <?php else : ?>
            <?php _e('No posts found', 'oren'); ?>
        <?php endif; ?>

    </div><!-- end container -->
</div><!-- end main-content-area -->


<?php get_footer(); ?>