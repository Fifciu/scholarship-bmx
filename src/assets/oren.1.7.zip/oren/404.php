<?php get_header(); ?>

<div class="full-width-container">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 text-center">
                <?php if ( ! have_posts() ) : ?>
                    <h1 class="title"><?php _e('Sorry! We cant find that page!', 'oren'); ?></h1>
                    
                    <p><?php _e( 'Why not try searching for the page you want?', 'oren' ); ?></p>
                    <?php get_search_form(); ?>
                    
                <?php endif; ?>
            </div><!-- col-md-10 -->
        </div><!-- end row -->
    </div><!-- end container -->
</div><!-- end full-width-container -->

<?php get_footer(); ?>