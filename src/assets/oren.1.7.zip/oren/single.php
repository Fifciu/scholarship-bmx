<?php get_header(); ?>

<div class="full-width-container main-content-area post-<?php has_post_thumbnail( $post->ID ) ? print 'with-thumbnail' : print 'without-thumbnail'; ?>">
    
    <article <?php post_class('container'); ?>>
        <header>
            <h1><?php the_title(); ?></h1>
            <?php themeora_entry_meta(); ?>
            <?php themeora_post_media( $post->ID, 'full-size' ); ?>
        </header>
        <div class="post-content content">
            <div class="col-md-10 col-md-offset-1">
                <?php if ( have_posts() ) : ?>
                    <?php while (have_posts()) : the_post(); ?>
                        <?php the_content(); ?>
                    <?php endwhile; ?>
                <?php endif; ?>
                <?php themeora_jetpack_shares(); ?>
            </div><!-- end col-md-8 -->
            <?php //get_sidebar(); ?>
        </div>
    </article><!-- end container -->
    
    <!-- begin meta area -->
    <div class="meta-space">
        <?php 
        //load post navigation
        themeora_post_nav();
        ?>
    </div>
    <!-- end meta-space area -->
                        
    <div class="container">
        <!-- begin comments -->
        <div class="blog-comments">
            <?php comments_template(); ?>
        </div>
        <!-- end comments -->
    </div>
</div><!-- end full-width-container -->

<?php get_footer(); ?>