<?php 
get_header();
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
?>

<?php if ( 1 === $paged ) : ?> 
    <header class="full-width-container no-bottom-padding" role="banner">
        <div class="container">
            <div class="col-md-10 col-md-offset-1">
                <?php if ( have_posts() ) : ?>
                    <?php the_post(); ?>
                    <?php echo get_avatar( get_the_author_meta('ID'), 100 ); ?>
                    <h1 class="archive-title"><?php printf( __( 'All posts by %s', 'oren' ), get_the_author() ); ?></h1>
                    <?php rewind_posts(); ?>
                        <?php 
                    /* Only show the author description if we are on page 1 to avoid duplicate content.
                    * First we check if we are paging or not
                    */

                    ?>             
                    <?php if ( get_the_author_meta( 'description' ) ) : ?>
                        <div class="category-description">
                            <p><?php the_author_meta('description'); ?></p>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div><!-- end col-md-10 -->
        </div><!-- end container -->
    </header>
<?php endif; ?>

<?php
$layout = get_theme_mod('themeora_blog_layout', 'full-width');
?>

<?php if ( have_posts() ) : ?>
   
    <?php get_template_part( 'templates/blog-sidebar' ); ?>
    
<?php endif; ?>

<?php get_footer(); ?>