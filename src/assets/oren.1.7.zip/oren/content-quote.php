<?php

/*
 * Used for quote
 */
// Get the layout set in theme options
$layout = get_theme_mod('themeora_blog_layout', 'sidebar');
$post_classes = array('post-teaser');
?>

<article id="post-<?php the_ID(); ?>" <?php post_class($post_classes); ?>>
    <?php 
    //load the post media depending on what kinf of post it is
    themeora_post_media( $post->ID, 'themeora-thumbnail-span-12' ); 
    ?>
    
    <div class="content">
        <?php if ( is_single() ) : ?>
            <?php 
            echo the_content(); 
            wp_link_pages('before=<div id="page-links">&after=</div>');
            ?>
        <?php else : ?>
            <a class="blockquote-link" href="<?php the_permalink() ?>"><?php echo the_content(); ?></a>
        <?php endif; ?>
    </div>
</article><!-- end post-teaser -->
