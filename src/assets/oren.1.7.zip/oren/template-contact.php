<?php
/*
 * Template Name: Contact page
*/
get_header();
// Get theme options
$enable_parallax = get_theme_mod('themeora_enable_parallax', 'yes');
$parallax_settings = '';
if ( 'yes' === $enable_parallax ){
    //advanced users can change this line to change the parallax effect. For documentation check https://github.com/Prinzhorn/skrollr
    $parallax_settings = 'data-center="background-position: 50% 50%;"
    data-top-bottom="background-position: 50% 20%;"';
}
// Get the featured image to set as the background of the header. Use header_image if set, featured image if not
$background_image = '';
if ( wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full-size' ) ) {
    $background_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full-size' );
    $background_image = $background_image[0];
}
if ( get_header_image() ) {
    $background_image = get_header_image();
}
?>

<header <?php echo $parallax_settings; ?> class="full-width-container center-page welcome-screen <?php $background_image != '' ? print 'header-with-background' : '' ?>  <?php has_excerpt() ? print 'header-with-excerpt ' : print 'header-without-excerpt'; ?>" role="banner" data-welcome-background="<?php echo $background_image; ?>" >
    <div class="container">
        <div class="col-md-10 col-md-offset-1">
            <h1 class="title <?php !has_excerpt() ? print 'no-bottom-margin' : ''; ?>" ><span><?php the_title(); ?></span></h1>
            <?php 
            if ( has_excerpt() ) {
                the_excerpt();
            }
            ?>
        </div>
    </div>
</header>

<div class="full-width-container main-content-area">
    
    <div class="container">
        <div class="row">
            <?php if ( is_active_sidebar( 'contact-sidebar' ) ) : ?>
                <div class="col-md-4 col-md-offset-2">
            <?php else : ?>
                <div class="col-md-8 col-md-offset-2 text-center">
            <?php endif; ?>
                <?php if ( have_posts() ) : ?>
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php the_content(); ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <?php _e('No posts found', 'oren'); ?>
                <?php endif; ?>

            </div>
            
            <?php if ( is_active_sidebar( 'contact-sidebar' ) ) : ?>
                <div class="col-md-3 col-md-offset-1 sidebar">
                    <?php dynamic_sidebar( 'contact-sidebar' ); ?>
                </div><!-- end sidebar -->
            <?php endif; ?>

        </div><!-- end row -->
    </div><!-- end container -->
</div><!-- end full-width-container -->


<?php get_footer(); ?>