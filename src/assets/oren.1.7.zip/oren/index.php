<?php 
get_header(); 
$show_banner = get_theme_mod('themeora_show_blog_header', 'Yes');

// Setup paging to determine if the header should be shown
if ( get_query_var('paged') ) {
    $paged = get_query_var('paged');
} elseif ( get_query_var('page') ) {
    $paged = get_query_var('page');
} else {
    $paged = 1;
}
?>

<?php
if ( $show_banner == 'Yes' && $paged === 1 ) {
    if ( 'page' == get_option('show_on_front') && get_option('page_for_posts') && is_home() ) : the_post();
        $page_for_posts_id = get_option('page_for_posts');
        setup_postdata( get_page($page_for_posts_id) );

        // Get the featured image to set as the background of the header. Use header_image if set, featured image if not
        $background_image = '';

        if ( get_header_image() ) {
            $background_image = get_header_image();
        }
    ?>
        <header class="full-width-container <?php $background_image != '' ? print 'header-with-background' : '' ?> <?php has_excerpt() ? print 'header-with-excerpt ' : print 'header-without-excerpt'; ?> center-page welcome-screen " role="banner" data-welcome-background="<?php echo $background_image; ?>" >
            <div class="container welcome-container">
                <div class="row welcome-row">
                    <div class="col-md-10 col-md-offset-1 welcome-content scrollable skrollable-between">
                        <h1 class="title"><span><?php single_post_title(); ?></span></h1>
                        <?php the_content(); ?>
                    </div><!-- end col-md-10 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </header>
    <?php
        wp_reset_query();
        rewind_posts();
    endif;
} // end show_banner
?>


<?php if ( have_posts() ) : ?>
    
    <?php get_template_part( 'templates/blog-sidebar' ); ?>
    
<?php endif; ?>
    
<?php get_footer(); ?>