<?php
/**
 * This template adds the Getting Started page, license settings and the theme updater.
 *
 * @package WordPress
 * @subpackage Oren
 */


/**
 * Add Getting Started menu item
 */
function oren_license_menu() {
	add_theme_page( __( 'Getting Started', 'oren' ), __( 'Getting Started', 'oren' ), 'manage_options', 'oren-getting-started', 'oren_getting_started_page' );
}
add_action('admin_menu', 'oren_license_menu');


/**
 * Load Getting Started styles in the admin
 */
function oren_start_load_admin_scripts() {

	// Load styles only on our page
	global $pagenow;
	if( 'themes.php' != $pagenow )
		return;

	// Getting started script and styles
	wp_register_style( 'getting-started', get_template_directory_uri() . '/inc/admin/getting-started/getting-started.css', false, '1.0.0' );
	wp_enqueue_style( 'getting-started' );

	// Thickbox
	add_thickbox();
}
add_action( 'admin_enqueue_scripts', 'oren_start_load_admin_scripts' );


/**
 * Create the Getting Started page and settings
 */
function oren_getting_started_page() {

	// Theme info
	$theme = wp_get_theme( 'oren' );

	// Lowercase theme name for resources links
	$theme_name_lower = get_template();
	?>

	<div class="wrap getting-started">
		<div class="intro-wrap">
                    <img class="theme-image" src="<?php echo get_template_directory_uri() . '/screenshot.png'; ?>" alt="" />
                    <div class="intro">
                        <h2><?php printf( __( 'Getting started with %1$s v%2$s', 'oren' ), $theme['Name'], $theme['Version'] ); ?></h2>

                        <h3><?php printf( __( 'Thanks for using %1$s! We truly appreciate the support and the chance to share our work with you. Please visit the tabs below to get started setting up your theme!', 'oren' ), $theme['Name'] ); ?></h3>
                    </div>
		</div>

		<div class="panels">

			<!-- general file panel -->
			<div id="help-panel" class="panel visible clearfix">
				<div class="panel-left">
                                    <h4><?php _e( 'Quick Start Guide', 'oren' ); ?></h4>
                                    
                                    <p><?php _e( 'Head over to <em>Appearance</em> &rarr; <em>Customize</em> and upload your logo if required.', 'oren' ); ?></p>
                                    <p><?php _e( 'Go to <em>Settings</em> &rarr; <em>Reading</em> and select a page to use as your homepage. If you don\'t have one yet, just create a page first.', 'oren' ); ?></p>
                                    <p><?php _e( 'When you have a page that you want to use for the homepage, go to that page and select the <em>Home</em> template under <em>Page Attributes &rarr; Template</em>.', 'oren' ); ?></p>
                                    <p><?php _e( 'Go to <em>Settings</em> &rarr; <em>Reading</em> and select a page to use as your blog. If you don\'t have one yet, just create a page first.', 'oren' ); ?></p>
                                    <p><?php _e( 'To set up your portfolio, create a new page, enter your content and set a featured image. Then select the <em>Portfolio item</em> template as the template. This will then show on the page you have assigned the <em>Home</em> template to. Do the same for all the items you want to add to your portfolio.', 'oren' ); ?></p>
                                    
                                    <h4><?php _e( 'Header Text', 'oren' ); ?></h4>
                                    <p><?php _e( 'Text in headers under the title comes from the excerpt field.', 'oren' ); ?></p>
                                    
                                    <h4><?php _e( 'Contact Page', 'oren' ); ?></h4>
                                    <p><?php _e( 'You can use the Jetpack contact form or use another plugin such as Contact Form 7 to create a contact form. Use the page template called "Contact page" for your contact page.', 'oren' ); ?></p>
				</div>

				<div class="panel-right">
					
                                    <div class="panel-aside hide-cm">
                                        <h4><?php _e( 'Turbo Charge this Theme!', 'oren' ); ?></h4>
                                        <p><?php _e( 'ZENO is the big brother to Oren. Upgrade for way more options and a more advanced theme to really make your work shine. You also get premium email support!', 'oren' ); ?></p>

                                        <a class="button button-primary" href="https://themeora.com/portfolio/zeno-single-page-responsive-portfolio-theme/?utm_source=oren&utm_medium=wp.org&utm_campaign=getting%20started" target="_blank" title=""><?php _e( 'See ZENO', 'oren' ); ?></a>
                                    </div>
                                   
                                    <div class="panel-aside hide-cm">
                                        <h4><?php _e( 'Explore More Themes', 'oren' ); ?></h4>
                                        <p><?php _e( 'Find handy WordPress tips and explore more awesome themes at <a href="https://themeora.com?utm_source=oren&utm_medium=wp.org&utm_campaign=getting%20started" target="_blank">themeora.com</a>.', 'oren' ); ?></p>

                                        <a class="button button-primary" href="https://themeora.com/?utm_source=oren&utm_medium=wp.org&utm_campaign=getting%20started" target="_blank" title=""><?php _e( 'Visit Themeora', 'oren' ); ?></a>
                                    </div>

				</div>
			</div><!-- #help-panel -->

		</div><!-- .panels -->
	</div><!-- .getting-started -->

	<?php
}

/**
 * Getting Started notice
 */

function oren_getting_started_notice() {
    global $current_user;
    $user_id = $current_user->ID;

    // Getting Started URL
    $getting_started_url = admin_url( 'themes.php?page=oren-getting-started' );

    if ( ! get_user_meta( $user_id, 'oren_getting_started_ignore_notice' ) ) {
            echo '<div class="updated"><p>';

            printf( __( ' %1$s activated! Visit the <a href="%2$s">Getting Started</a> page to view the help file or ask us a question. ', 'oren' ), wp_get_theme(), esc_url( $getting_started_url ) );

            printf( __( '<a href="%1$s">Hide this notice</a>', 'oren' ), '?oren_getting_started_nag_ignore=0' );

            echo "</p></div>";
    }
}
add_action( 'admin_notices', 'oren_getting_started_notice' );


function oren_getting_started_nag_ignore() {
    global $current_user;
        $user_id = $current_user->ID;
        /* If user clicks to ignore the notice, add that to their user meta */
        if ( isset( $_GET['oren_getting_started_nag_ignore'] ) && '0' == $_GET['oren_getting_started_nag_ignore'] ) {
            add_user_meta( $user_id, 'oren_getting_started_ignore_notice', 'true', true );
    }
}
add_action( 'admin_init', 'oren_getting_started_nag_ignore' );