<?php

/* 1. Define constants
/*=================================================================== */

/* Define theme URL */
if ( !defined( 'WP_THEME_URL' ) ) {
    define( 'WP_THEME_URL', get_template_directory_uri() );
}

// Directory location constants
define('PARENT_DIR', get_template_directory());
define('CHILD_DIR', get_stylesheet_directory());

// Theme URL constants
define('PARENT_URL', get_template_directory_uri());
define('CHILD_URL', get_stylesheet_directory_uri());

// General constants
define('THEMEORA_FRAMEWORK_DIR', PARENT_DIR . '/inc/');
define('THEMEORA_JS_DIR', PARENT_DIR . '/inc/assets/js');
define('THEMEORA_CSS_DIR', PARENT_DIR . '/inc/assets/css/');
define('THEMEORA_CUSTOMIZER_DIR', PARENT_DIR . '/inc/');
define('THEMEORA_CUSTOMIZER_URL', PARENT_DIR . '/inc/');

// Widget constants
define('THEMEORA_WIDGETS_DIR', THEMEORA_FRAMEWORK_DIR . 'widgets');
define('THEMEORA_WIDGETS_URL', THEMEORA_FRAMEWORK_DIR . 'widgets');

// Framework constants
define('THEMEORA_FRAMEWORK_IMAGES_DIR', THEMEORA_FRAMEWORK_DIR . '/assets/images');
define('THEMEORA_FRAMEWORK_CSS_DIR', THEMEORA_FRAMEWORK_DIR . '/assets/css');
define('THEMEORA_FRAMEWORK_JS_DIR', THEMEORA_FRAMEWORK_DIR . '/assets/js');

define('THEMEORA_FRAMEWORK_URL', PARENT_URL . '/framework');
define('THEMEORA_FRAMEWORK_IMAGES_URL', THEMEORA_FRAMEWORK_URL . '/assets/images');
define('THEMEORA_FRAMEWORK_CSS_URL', THEMEORA_FRAMEWORK_URL . '/assets/css');
define('THEMEORA_FRAMEWORK_JS_URL', THEMEORA_FRAMEWORK_URL . '/assets/js');

do_action('themeora_pre');

/* Feature Setup
/* --------------------------------------------------------------------- */

if (!function_exists('themeora_feature_setup')) {

    function themeora_feature_setup() {
        $args = array(
            'wordpress' => array(
                'org' => true, //WordPress.org environment
                'com' => false, //WordPress.com environment
            ),
            'primary' => array(
                'adminstyles' => true,
                'customizer' => true,
                'fonts' => true,
                'meta' => false,
                'widgets' => true,
                'suggest-plugins' => false
            ),
            'comments' => array(
                'posts' => true,
                'pages' => false,
                'portfolio' => false,
            )
        );

        return apply_filters('themeora_theme_config_args', $args);
    }

    add_action('themeora_init', 'themeora_feature_setup');
} //END if ( !function_exists( 'themeora_feature_setup' ) )


// FEATURE SETUP RETURN
/* --------------------------------------------------------------------- */

function themeora_theme_supports( $group, $feature ) {
    $setup = themeora_feature_setup();
    if ( isset( $setup[$group][$feature] ) && $setup[$group][$feature] )
        return true;
    else {     
    }
}


/* LOAD FRAMEWORK
/* --------------------------------------------------------------------- */

function themeora_load_framework() {
    
    /* Load specific functionality for .org or .com environments */
    if ( themeora_theme_supports('wordpress', 'org') ) {
        if( file_exists( get_template_directory() . '/inc/wporg.php' ) ) {
            require_once( get_template_directory() . '/inc/wporg.php' );
        }
    }
    if ( themeora_theme_supports('wordpress', 'com') ) {
        if( file_exists( get_template_directory() . '/inc/wpcom.php' ) ) {
            require_once( get_template_directory() . '/inc/wpcom.php' );
        }
    }

    // Theme customizer
    if ( themeora_theme_supports('primary', 'customizer' )) {
        require( THEMEORA_CUSTOMIZER_DIR . '/themeora-customizer.php' );
    } //END if( themeora_theme_supports( 'primary', 'customizer' ))
    
    
    // Load custom editor style
    add_action( 'admin_enqueue_scripts', 'themeora_add_editor_styles' );
    function themeora_add_editor_styles() {
        add_editor_style( 'custom-editor-style.css' );
    }
    
    // Custom header
    include( get_template_directory()  . '/inc/custom-header.php' );
}

add_action( 'themeora_init', 'themeora_load_framework' );

/* Run the init hook */
do_action( 'themeora_init' );


/**
 * Adds the required text to the footer for WordPress.com
 */
function themeora_filter_footer_text() {
    $theme_name = wp_get_theme();
    //$output = '<a href="http://wordpress.org/" title="' . esc_attr( 'A Semantic Personal Publishing Platform', 'oren' ) .'" rel="generator">' . sprintf( __( 'Proudly powered by %s', 'oren' ), 'WordPress' ). '</a>';
    $output = sprintf( __( 'Proudly powered by %s', 'oren' ), 'WordPress' );
    $output .= '<span class="sep"> | </span>';
    $output .= sprintf( __( 'Theme: %1$s by %2$s.', 'oren' ), $theme_name, '<a href="https://themeora.com/" rel="designer">Themeora</a>' );
    return $output;
}
add_filter( 'themeora_footer_text', 'themeora_filter_footer_text' );

/* end themeora framework */