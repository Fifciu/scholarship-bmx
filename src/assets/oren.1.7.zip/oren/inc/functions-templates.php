<?php

if ( ! function_exists( 'themeora_entry_meta' ) ) :
/**
 * Prints HTML with meta information for current post: categories, tags, permalink, author, and date.
 * @since themeora 1.0
 * @param boolean shorten. Weather to shorten by removing category information. Default false.
 * @return string block of html for blog meta.
 */
function themeora_entry_meta($shorten = false) {
    global $post;
	if ( is_sticky() && is_home() && ! is_paged() )
		echo '<span class="featured-post">' . __( 'Sticky', 'oren' ) . '</span>';

	if ( 'post' == get_post_type() ) {
        echo '<div class="meta">';
            //echo __('Posted on', 'oren') . ' ';
            echo get_the_time('jS') . ' ' . get_the_time('F');
            echo '. ' . __('By', 'oren') . ' ' ;
            $username = get_userdata( $post->post_author );
            echo '<a href="' . get_author_posts_url( $post->post_author ) . '">' . $username->user_nicename . '</a>';
            if ( ! $shorten ) {
                echo '. ' . __('Posted in', 'oren') . ' '; 
                the_category(', ');
                echo '.';
            }
            ?>
        <?php echo '</div>';
    }
}
endif;

if ( ! function_exists( 'themeora_entry_date' ) ) :
/**
 * Prints HTML with date information for current post.
 * @since themeora 1.0
 * @param boolean $echo Whether to echo the date. Default true.
 * @return string The HTML-formatted post date.
 */
function themeora_entry_date( $echo = true ) {
	if ( has_post_format( array( 'chat', 'status' ) ) )
            $format_prefix = _x( '%1$s on %2$s', '1: post format name. 2: date', 'oren' );
	else
            $format_prefix = '%2$s';
	$date = sprintf( '<span class="date"><a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a></span>',
		esc_url( get_permalink() ),
		esc_attr( sprintf( __( 'Permalink to %s', 'oren' ), the_title_attribute( 'echo=0' ) ) ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( sprintf( $format_prefix, get_post_format_string( get_post_format() ), get_the_date() ) )
	);

	if ( $echo )
		echo $date;

	return $date;
}
endif;


if ( ! function_exists( 'themeora_post_tags' ) ) :
/**
* Displays post tags
* @since themeora 1.0
* @return tag cloud
*/
function themeora_post_tags() {
    global $post;
    if( get_theme_mod( 'show_tags' ) == true && has_tag() && is_singular() ) {
        echo '<div class="styled-box post-tags">';
        echo the_tags( '<h3>' . __('Tagged As', 'oren') . '</h3>', '', '' );
        echo '</div>';
    }
}
endif;


if ( ! function_exists( 'themeora_post_author_meta' ) ) :
/**
 * Displays author information under posts
*  @since themeora 1.0
*  @return block of html to display author info
*/
function themeora_post_author_meta() {
    
    if ( 'post' == get_post_type() && get_the_author_meta('first_name') != '' && get_the_author_meta('last_name') != '') { ?>
        <div class="container">
            <div class="post-author styled-box">
                <?php echo get_avatar( get_the_author_meta('ID'), 80 ); ?>
                <h2><?php _e('Author', 'oren') ?>: <a href="<?php echo home_url(); ?>/?author=<?php the_author_meta('ID'); ?>" title="<?php _e('Posts by ', 'oren'); the_author_meta('first_name'); print ' '; the_author_meta('last_name'); ?>">
                <?php the_author_meta('first_name'); ?> <?php the_author_meta('last_name'); ?></a></h2>
                <p><?php the_author_meta('description'); ?></p>
                <a href="<?php echo home_url(); ?>/?author=<?php the_author_meta('ID'); ?>">
                    <?php the_author_meta('first_name'); ?> <?php the_author_meta('last_name'); ?>
                    <?php _e('has', 'oren'); ?>
                    <?php the_author_posts(); ?> 
                <?php
                count_user_posts( get_the_author_meta('ID') ) == 1 ? _e('article', 'oren') : _e('articles', 'oren');
                ?></a>.
            </div>
        </div>
    <?php
    }
    
}
endif;


if ( ! function_exists( 'themeora_post_nav' ) ) :
/**
* Displays next/previous post when applicable.
* @since themeora 1.0
* @return next and prev posts links
*/
function themeora_post_nav() {
    global $post;
    
    // Don't print empty markup if there's nowhere to navigate.
    $previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
    $next     = get_adjacent_post( false, '', false );

    if ( ! $next && ! $previous )
        return;
    ?>
    <div class="container">
        <nav class="" role="navigation">
            <div class="nav-links post-navigation <?php get_previous_post_link() && get_next_post_link() ? print 'post-navigation-both-buttons' : '' ?>">
                <?php if ( get_previous_post_link() ) : ?>
                    <span class="nav-links-prev hvr-wobble-horizontal"><?php previous_post_link( '%link', __( '<i class="fa fa-chevron-left"></i> Previous', 'oren' ) ); ?></span>
                <?php endif; ?>

                <?php if ( get_next_post_link() ) : ?>
                    <span class="nav-links-next hvr-wobble-horizontal"><?php next_post_link( '%link', __( 'Next <i class="fa fa-chevron-right"></i>', 'oren' ) ); ?></span>
                <?php endif; ?>
            </div>
        </nav><!-- .navigation -->
    </div>
    <?php
    
}
endif;


if ( ! function_exists( 'themeora_paging' ) ) :
/**
 * Displays pagination for blog pages when applicable.
 * @since themeora 1.0
 * @return block of html with paging links
 */
function themeora_paging() {
    global $wp_query;
    $layout = get_theme_mod('themeora_blog_layout', 'sidebar');
    // Don't print empty markup if there's only one page.
    if ( $wp_query->max_num_pages < 2 )
            return;
    ?>
    <div class="container article_nav blog-layout-<?php echo $layout ?>">
        <nav class="navigation paging-navigation" role="navigation">
            <h2 class="screen-reader-text"><?php _e( 'Posts navigation', 'oren' ); ?></h2>
            <div class="nav-links post-navigation <?php get_previous_posts_link() && get_next_posts_link() ? print 'post-navigation-both-buttons' : '' ?>">
                <?php if ( get_previous_posts_link() ) : ?>
                    <span class="nav-links-prev"><?php previous_posts_link( __( '<i class="fa fa-chevron-left"></i> <span class="">Previous</span>', 'oren' ) ); ?></span>
                <?php endif; ?>

                <?php if ( get_next_posts_link() ) : ?>
                    <span class="nav-links-next"><?php next_posts_link( __( '<span class="">Next</span> <i class="fa fa-chevron-right"></i>', 'oren' ) ); ?></span>
                <?php endif; ?>
            </div>            
        </nav><!-- .navigation -->
    </div>
	<?php
}
endif;


if ( ! function_exists( 'themeora_post_media' ) ) :
/**
 * Displays the correct media above a post, featured, image, gallery, video or audio
 * @since themeora 1.0
 * @param int post. The id of the post.
 * @param string size. The size for featured images
 * @return html for the post media
 */
function themeora_post_media( $postId, $size = null ){
    //check for a featured image
    if ( has_post_thumbnail( $postId ) ) : ?>
        <div class="featured-image">
            <?php if ( is_single() ) : ?>
                <?php echo get_the_post_thumbnail( $postId, $size ); ?>
            <?php else : ?>
                <a href="<?php the_permalink(); ?>"><?php echo get_the_post_thumbnail( $postId, $size ); ?></a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php
}
endif;


if ( ! function_exists( 'themeora_load_content' ) ) :
/**
 * Checks the post type and loads the right content from the includes folder
 * @since themeora 1.0
 * @param int post. The id of the current post
 * @return A block of html for each type of content
 */
function themeora_load_content( $post ){
    //load the content for quotes
    if ( get_post_format($post) == "quote" )
        get_template_part('templates/content', 'quote');
    //load the content for galleries
    elseif ( get_post_format($post) == "gallery" )
        get_template_part('templates/content', 'gallery');
    elseif ( get_post_format($post) == "link" )
        get_template_part('templates/content', 'link');
    //load content for any other post type
    else
        get_template_part('templates/content', 'standard');
}
endif;

if ( ! function_exists( 'themeora_excerpt_more' ) ) :
/**
 * Add our own read more link to the except
 * @return block of html for a read more link
 */

function themeora_excerpt_more() {
	return ' <a class="read-more" href="'. get_permalink( get_the_ID() ) . '">'. __('...read more', 'oren') . '</a>';
}
endif;

add_filter( 'excerpt_more', 'themeora_excerpt_more' );


if ( ! function_exists( 'themeora_default_page_loop' ) ) :
/**
 * Default loop
 *
 * Run a loop based off the provided page id. If no id is passed in, just do a standard loop.
 * Used to return various pages for the single page template.
 * @param int $page. The id of the page
 * @param boolean $sidebar. Should the sidebar be shown
 * @return the page structure for full width or default page
 */
function themeora_default_page_loop( $page = null, $sidebar = null ) { 
    $col_span = $sidebar === true ? 'col-md-8' : 'col-md-12';
    $template = get_page_template_slug( $page );
    ?>
    <div class="full-width-container <?php echo $template; ?>">
        <div class="container">
            <div class="row">
                <div class="<?php echo $col_span ?>">
                    <article class="single-page-article styled-box">
                        <div class="content">
                            <?php if ( have_posts() ) : ?>
                                <?php while ( have_posts() ) : the_post(); ?>
                                    <h1 class="title"><span><?php the_title(); ?></span></h1>
                                    <?php the_content(); ?>
                                    
                                <?php endwhile; ?>
                            <?php else : ?>
                                <?php _e('No posts found', 'oren'); ?>
                            <?php endif; ?>
                        </div>
                    </article><!-- end col-md-8 / col-md-12 -->
                    
                    <!-- begin comments -->
                    <?php if ( comments_open() || get_comments_number() ) : ?>
                        <div class="blog-comments styled-box mobile-stack">
                            <?php comments_template(); ?>
                        </div>
                    <?php endif; ?>
                    <!-- end comments -->
                    
                </div>
                <?php 
                if ( $sidebar === true ) {
                    get_sidebar('page');
                }
                ?>

            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end main-content-area -->
<?php }
endif;


if ( ! function_exists( 'themeora_get_link_url' ) ) :
/**
 * Return the post URL.
 *
 * @uses get_url_in_content() to get the URL in the post meta (if it exists) or
 * the first link found in the post content.
 *
 * Falls back to the post permalink if no URL is found in the post.
 * @since themeora 1.0
 * @return string The Link format URL.
 */
function themeora_get_link_url() {
	$content = get_the_content();
	$has_url = get_url_in_content( $content );

	return ( $has_url ) ? $has_url : apply_filters( 'the_permalink', get_permalink() );
}
endif;


/* Custom Comment Output */
function themeora_comment( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment; ?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">

        <div class="comment-block" id="comment-<?php comment_ID(); ?>">

            <div class="comment-info">
                <div class="comment-author vcard">
                    <div class="vcard-wrap">
                        <?php echo get_avatar($comment->comment_author_email, 100); ?>
                    </div>
                </div>

                <div class="comment-text">
                    <div class="comment-meta commentmetadata">
                        <?php printf(__('<cite class="fn">%s</cite>', 'oren'), get_comment_author_link()); ?>

                        <div class="comment-time">
                            <?php
                            printf('<a href="%1$s"><time datetime="%2$s">%3$s</time></a>', esc_url(get_comment_link($comment->comment_ID)), get_comment_time('c'),
                            /* translators: 1: date, 2: time */ 
                            sprintf(__('%1$s at %2$s', 'oren'), get_comment_date(), get_comment_time())
                            );
                            ?>
                            <?php edit_comment_link('<i class="fa fa-edit"></i>', ''); ?>
                        </div>
                    </div>

                    <?php comment_text(); ?>

                    <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
                </div>
            </div>

             <?php if ($comment->comment_approved == '0') : ?>
                <em class="comment-awaiting-moderation"><?php _e('Your comment is awaiting moderation.', 'oren'); ?></em>
            <?php endif; ?>
        </div>
    
<?php
}

if ( ! function_exists( 'themeora_jetpack_shares' ) ) :
/**
 * Show Jetpack sharing buttons if available
 *
 * @since Themeora 1.0
 * @return Social share icons html
 */
function themeora_jetpack_shares() {
	if ( function_exists( 'sharing_display' ) ) {
        echo '<div class="themeora-shares">';
        sharing_display( '', true );
        echo '</div>';
    }

    if ( class_exists( 'Jetpack_Likes' ) ) {
        $custom_likes = new Jetpack_Likes;
        echo '<div class="themeora-shares">' . $custom_likes->post_likes( '' ) . '</div>';
    }
}
endif;
