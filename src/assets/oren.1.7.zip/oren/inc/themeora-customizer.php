<?php

/* Load the live preview js
  ---------------------------------------------------------------------------------------------------- */
add_action('customize_preview_init', 'themeora_customizer_live_preview');

function themeora_customizer_live_preview() {
    wp_enqueue_script('customizer', get_template_directory_uri() . '/inc/customizer-preview.js', 'jquery', '1.0', true);
}

/* General settings
  ---------------------------------------------------------------------------------------------------- */
add_theme_support('custom-background');

add_action('customize_register', 'Themeora_Customize_Register');

function Themeora_Customize_Register($wp_customize) {

    /* Custom textarea control
    ----------------------------------------------------------------------------------------------------*/
    class Themeora_Customize_Textarea_Control extends WP_Customize_Control {
        public $type = 'textarea';
        public function render_content() { ?>
            <label><span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span></label>
            <textarea rows="4" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
        <?php
        }
    }

    
    /* Add theme options section
    ---------------------------------------------------------------------------------------------------- */
    
    $wp_customize->add_section('themeora_customizer_general', array(
        'title' => __('Theme Options', 'oren'),
        'description' 	=> __( '', 'oren' ),
        'priority' => 1,
        )
    );
    
    /* Img upload
    ---------------------------------------------------------------------------------------------------- */
    
    $wp_customize->add_setting('themeora-img-upload-logo', array(
        'sanitize_callback' => 'esc_url',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'themeora-img-upload-logo', array(
        'label' => __('Logo', 'oren'),
        'section' => 'themeora_customizer_general',
        'settings' => 'themeora-img-upload-logo',
        'priority' => 1
     )));
    
    $wp_customize->add_setting('themeora-img-upload-logo-width', array(
        'default' => '',
        'sanitize_callback' => 'themeora_sanitize_int',
    ));
    $wp_customize->add_control('themeora-img-upload-logo-width', array(
        'label' => __('Logo width (px)', 'oren'),
        'section' => 'themeora_customizer_general',
        'type' => 'text',
        'priority' => 2,
        )
    );
    
     $wp_customize->add_setting('themeora-img-upload-logo-padding', array(
        'default' => '',
        'sanitize_callback' => 'themeora_sanitize_int',
    ));
    $wp_customize->add_control('themeora-img-upload-logo-padding', array(
        'label' => __('Menu top / bottom padding (px)', 'oren'),
        'section' => 'themeora_customizer_general',
        'type' => 'text',
        'priority' => 3,
        )
    );
    
    $wp_customize->add_setting('themeora-show-description-header', array(
        'default' => 'No',
        'sanitize_callback' => 'themeora_sanitize_text',
        ));
    $wp_customize->add_control('themeora-show-description-header', array(
        'type' => 'select',
        'label' => __('Show description in header', 'oren'),
        'section' => 'themeora_customizer_general',
        'priority' => 3,
        'choices'    	=> array(
            'No' 	=> __( 'No', 'oren' ),
            'Yes' 	=> __( 'Yes', 'oren' ),
        ),
    ));

    
    /* Portfolio settings
    ---------------------------------------------------------------------------------------------------- */
 
    $wp_customize->add_setting('themeora_portfolio_related', array(
        'default' => 'yes',
        'sanitize_callback' => 'themeora_sanitize_text',
    ));
    $wp_customize->add_control('themeora_portfolio_related', array(
        'type' => 'select',
        'label' => __('Show related posts on portfolio?', 'oren'),
        'section' => 'themeora_customizer_general',
        'priority' => 4,
        'choices' => array('yes' => __('Yes', 'oren'),'no' => __('No', 'oren') )
        )
    );

    
    /* Blog settings
      ---------------------------------------------------------------------------------------------------- */
    
    
    $wp_customize->add_setting('themeora_show_blog_header', array(
        'default' => 'Yes',
        'sanitize_callback' => 'themeora_sanitize_text',
        ));
    $wp_customize->add_control('themeora_show_blog_header', array(
        'type' => 'select',
        'label' => __('Show banner above blog posts page', 'oren'),
        'section' => 'themeora_customizer_general',
        'priority' => 11,
        'choices'    	=> array(
            'No' 	=> __( 'No', 'oren' ),
            'Yes' 	=> __( 'Yes', 'oren' ),
        ),
    ));
    
    
    /* Transport for live previews
    ---------------------------------------------------------------------------------------------------- */

    $wp_customize->get_setting('blogname')->transport = 'postMessage';
    $wp_customize->get_setting('themeora-img-upload-logo-width')->transport = 'postMessage';

}

/* Sanetize callbacks
---------------------------------------------------------------------------------------------------- */

function themeora_sanitize_checkbox( $input ) {
	if ( $input == 1 ) {
		return 1;
	} else {
		return '';
	}
}

//Integers
function themeora_sanitize_int( $input ) {
    if( is_numeric( $input ) ) {
        return intval( $input );
    }
}

//Text
function themeora_sanitize_text( $input ) {
    return wp_kses_post( force_balance_tags( $input ) );
}

//Url
function themeora_sanitize_url( $input ) {
    return esc_url( $input );
}

function themeora_sanitize_text_field( $input ) {
    return wp_kses_post( $input );
}