<?php
/**
 * WordPress.com-specific functions and definitions
 * This file is centrally included from `wp-content/mu-plugins/wpcom-theme-compat.php`.
 *
 * @package themeora
 */

/**
 * Theme Colors for WordPress.com
 */
if ( ! isset( $themecolors ) ) {
	$themecolors = array(
		'bg'     => 'f7f7f7',
		'border' => 'eeeeee',
		'text'   => '5F646D',
		'link'   => '469AF6',
		'url'    => '469AF6',
	);
}


/**
 * Add wpcom class to body if we're on WordPress.com
 */
function themeora_body_class( $classes ) {
	$classes[] = 'wpcom';
	return $classes;
}
add_filter( 'body_class', 'themeora_body_class' );
