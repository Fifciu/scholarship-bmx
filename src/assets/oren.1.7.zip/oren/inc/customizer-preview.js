/**
 * This file adds some LIVE to the Theme Customizer live preview. To leverage
 * this, set your custom settings to 'postMessage' and then add your handling
 * here. This javascript will grab settings from customizer controls, and 
 * then make any necessary changes to the page using jQuery.
 */
 
( function( $ ) {
		
	//LIVE HTML
	wp.customize( 'blogname', function( value ) {
		value.bind( function( newval ) {
			$( '.logo-text' ).html( newval );
		} );
	} );
	
    wp.customize( 'themeora-img-upload-logo-width', function( value ) {
		value.bind( function( newval ) {
			$( '.logo-uploaded' ).css('width',  newval + 'px' );
		} );
	} );
    

} )( jQuery );
