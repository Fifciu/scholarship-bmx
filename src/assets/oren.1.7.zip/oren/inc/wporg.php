<?php
/**
 * Self-hosted functionality not to be included on WordPress.com
 *
 /**
 * @package WordPress
 * @subpackage Themeora Framework
 */


/**
 * Load the Getting Started page and Theme Update class
 */
if ( is_admin() ) {
    if( file_exists( get_template_directory() . '/inc/admin/getting-started/getting-started.php' ) ) {
        // Load Getting Started page and initialize EDD update class
        require_once( get_template_directory() . '/inc/admin/getting-started/getting-started.php' );
    }
}

/**
 * Registers additional customizer controls for .org only
 */
function themeora_register_customizer_options( $wp_customize ) {
    
    /* Typography
      ---------------------------------------------------------------------------------------------------- */

    //Colours
    $wp_customize->add_setting( 'themeora_customizer_accent', array(
        'default' => '#1abc9c',
        'sanitize_callback' => 'sanitize_hex_color',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'themeora_customizer_accent', array(
        'label'          => __( 'Accent Color', 'oren' ),
        'section'        => 'themeora_customizer_general',
        'settings'       => 'themeora_customizer_accent',
        'priority'       => 30
    ) ) );
	
}
add_action( 'customize_register', 'themeora_register_customizer_options' );

/**
 * Add Customizer CSS To Header
 */
function themeora_customizer_css() { ?>
	<style type="text/css">
        <?php if ( get_header_textcolor() ) : ?>
            .page-wrapper header.welcome-screen h1, 
            .page-wrapper header.welcome-screen p {
                color: #<?php echo get_header_textcolor(); ?>;
            }
        <?php endif; ?>
        
        .main-content-area a,
	.main-content-area a:visited, 
        .main-content-area a:active, 
        .main-content-area a:focus, 
        .main-content-area a:hover {
	    color: <?php echo get_theme_mod( 'themeora_customizer_accent', '#1abc9c' );?>;
	}
        
        .nav-links a, 
        .nav-links a:visited,
	.main-content-area .btn, 
        .main-content-area .btn:visited,
        .main-content-area .wpcf7-submit,
        .main-content-area #commentform #submit,
        body .main-content-area #infinite-handle span, 
        .main-content-area .contact-form .pushbutton-wide { border-color: <?php echo get_theme_mod( 'themeora_customizer_accent', '#1abc9c' );?>; }
        
        .nav-links a:hover, 
        .nav-links a:focus,
        .main-content-area .btn:hover,
        .main-content-area .btn:focus,
        .main-content-area .wpcf7-submit:hover,
        .main-content-area .wpcf7-submit:focus,
        .main-content-area #commentform #submit:hover,
        .main-content-area #commentform #submit:focus,
        body .main-content-area #infinite-handle span:hover, 
        body .main-content-area #infinite-handle span:focus, 
        .main-content-area .contact-form .pushbutton-wide:hover,
        .main-content-area .contact-form .pushbutton-wide:focus { border-color: <?php echo get_theme_mod( 'themeora_customizer_accent', '#1abc9c' );?>; }
        
	<?php echo wp_kses( get_theme_mod( 'themeora_customizer_css' ), '' );?>
	</style>
<?php
}
add_action( 'wp_head', 'themeora_customizer_css' );


/*
 Plugin activation
/* ------------------------------------------------------------------------ */

if ( themeora_theme_supports('primary', 'suggest-plugins') ) {

    require_once( THEMEORA_FRAMEWORK_DIR . 'class-tgm-plugin-activation.php');

    /* TGM plugin activation */

    add_action( 'tgmpa_register', 'themeora_register_required_plugins' );
    /**
    * Register the required plugins for this theme.

    * The variable passed to tgmpa_register_plugins() should be an array of plugin
    * arrays.
    *
    * This function is hooked into tgmpa_init, which is fired within the
    * TGM_Plugin_Activation class constructor.
    */
    function themeora_register_required_plugins() {

        /**
        * Array of plugin arrays. Required keys are name and slug.
        * If the source is NOT from the .org repo, then source is also required.
        */
        $plugins = array(

            // Recommend jetpack
            array(
                'name'               => 'Jetpack', // The plugin name.
                'slug'               => 'jetpack', // The plugin slug (typically the folder name).
                //'source'             => get_stylesheet_directory() . '/lib/plugins/tgm-example-plugin.zip', // The plugin source.
                'required'           => false, // If false, the plugin is only 'recommended' instead of required.
                'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
                'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
                'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
                'external_url'       => '', // If set, overrides default API URL and points to an external URL.
            ),
        );

        /**
        * Array of configuration settings. Amend each line as needed.
        * If you want the default strings to be available under your own theme domain,
        * leave the strings uncommented.
        * Some of the strings are added into a sprintf, so see the comments at the
        * end of each line for what each argument will be.
        */
        $config = array(
            'default_path' => '',                      // Default absolute path to pre-packaged plugins.
            'menu'         => 'tgmpa-install-plugins', // Menu slug.
            'has_notices'  => true,                    // Show admin notices or not.
            'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
            'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
            'is_automatic' => false,                   // Automatically activate plugins after installation or not.
            'message'      => '',                      // Message to output right before the plugins table.
            'strings'      => array(
                'page_title'                      => __( 'Install Required Plugins', 'oren' ),
                'menu_title'                      => __( 'Install Plugins', 'oren' ),
                'installing'                      => __( 'Installing Plugin: %s', 'oren' ), // %s = plugin name.
                'oops'                            => __( 'Something went wrong with the plugin API.', 'oren' ),
                'notice_can_install_required'     => __( 'This theme requires the following plugin: %1$s.', 'oren' ), // %1$s = plugin name(s).
                'notice_can_install_recommended'  => __( 'This theme recommends the following plugin: %1$s.', 'oren' ), // %1$s = plugin name(s).
                'notice_cannot_install'           => __( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'oren' ), // %1$s = plugin name(s).
                'notice_can_activate_required'    => __( 'The following required plugins are currently inactive: %1$s.', 'oren' ), // %1$s = plugin name(s).
                'notice_can_activate_recommended' => __( 'The following recommended plugins are currently inactive: %1$s.', 'oren' ), // %1$s = plugin name(s).
                'notice_cannot_activate'          => __( 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'oren' ), // %1$s = plugin name(s).
                'notice_ask_to_update'            => __( 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'oren' ), // %1$s = plugin name(s).
                'notice_cannot_update'            => __( 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'oren' ), // %1$s = plugin name(s).
                'install_link'                    => __( 'Begin installing plugins', 'oren' ),
                'activate_link'                   => __( 'Begin activating plugins', 'oren' ),
                'return'                          => __( 'Return to Required Plugins Installer', 'oren' ),
                'plugin_activated'                => __( 'Plugin activated successfully.', 'oren' ),
                'complete'                        => __( 'All plugins installed and activated successfully. %s', 'oren' ), // %s = dashboard link.
                'nag_type'                        => 'updated' // Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
            )
        );

        tgmpa( $plugins, $config );

    } // themeora_register_required_plugins()
} //end check for suggest-plugins