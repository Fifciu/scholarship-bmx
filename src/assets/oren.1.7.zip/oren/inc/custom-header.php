<?php
/**
* Add custom header with front-end styles and admin preview.
* @package Themeora
* @since Themeora 1.0
*/

add_theme_support( 'custom-header', apply_filters( 'themeora_custom_header_args', array(
    'default-text-color'     => 'fff',
    'width'                  => 1200,
    'height'                 => 650,
    'header-text'            => true,
    'wp-head-callback'       => 'themeora_header_style',
    'admin-head-callback'    => 'themeora_admin_header_style',
    'admin-preview-callback' => 'themeora_admin_header_image',
) ) );

//Front end header styles

if ( ! function_exists( 'themeora_header_style' ) ) :
function themeora_header_style() {
    $background_image = get_header_image();
    $header_text_color = get_header_textcolor();

    if ( ! empty( $background_image ) ) :
    ?>
    <style type="text/css">
        .welcome-screen {
            background-image: url(<?php echo $background_image; ?>);
            background-repeat: no-repeat;
            background-size: cover;
        }
        <?php if ( 'blank' == $header_text_color ) : ?>
		.welcome-content {
			position: absolute;
			clip: rect(1px, 1px, 1px, 1px);
		}
	<?php endif; ?>
    </style>
    <?php
    endif;
}
endif;


// Admin header preview

if ( ! function_exists( 'themeora_admin_header_style' ) ) :
function themeora_admin_header_style() {
?>
	
<?php
}
endif;

//Admin preview callback

if ( ! function_exists( 'themeora_admin_header_image' ) ) :
function themeora_admin_header_image() {
	
}
endif;