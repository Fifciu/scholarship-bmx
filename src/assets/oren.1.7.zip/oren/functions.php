<?php

if ( ! isset( $content_width ) )
    $content_width = 1170;

/* Load framework
----------------------------------------------------------------------------- */

if ( file_exists( get_template_directory(). '/inc/themeora-framework-init.php') ) {
    include_once ( get_template_directory(). '/inc/themeora-framework-init.php' );
}

/* General theme setup options
----------------------------------------------------------------------------- */

if ( ! function_exists( 'themeora_theme_setup' ) ) :

    function themeora_theme_setup() {
    
        /* Register Navigation 
        ------------------------------------------------------------------------------*/
        register_nav_menus( array(
            'primary_menu' => __( 'Primary Menu', 'oren' ),
            'social_menu' => __( 'Social Menu', 'oren' )
        ));
        
        /* Load editor style
        ------------------------------------------------------------------------------*/
        add_editor_style( 'custom-editor-style.css' );

        /* Load text domain
        ------------------------------------------------------------------------------*/
        load_theme_textdomain( 'oren', WP_THEME_URL . "/languages/" );

        /* Add various theme support options
        ----------------------------------------------------------------------------- */

        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );
        add_theme_support( 'custom-background' );
        add_theme_support( 'post-formats', array( 'quote') );
        add_theme_support( "title-tag" );
        // Add backwards compatibility for title-tag
        if ( ! function_exists( '_wp_render_title_tag' ) ) {
            function theme_slug_render_title() {
            ?>
                <title><?php wp_title( '|', true, 'right' ); ?></title>
                <?php
            }
            add_action( 'wp_head', 'theme_slug_render_title' );
        }
        add_post_type_support( 'page', 'excerpt' );
        
        /* Jetpack
        ----------------------------------------------------------------------------- */
        
        /* Infinite Scroll Support */
        add_theme_support( 'infinite-scroll', array(
            'container'	=> 'posts-wrapper',
            'footer'	=> 'primary-footer',
        ));
        
        // Remove default social share functionality
        function jptweak_remove_share() {
            remove_filter( 'the_content', 'sharing_display',19 );
            remove_filter( 'the_excerpt', 'sharing_display',19 );
            if ( class_exists( 'Jetpack_Likes' ) ) {
                remove_filter( 'the_content', array( Jetpack_Likes::init(), 'post_likes' ), 30, 1 );
            }
        }

        add_action( 'loop_start', 'jptweak_remove_share' );
        
        /* Custom header
        ----------------------------------------------------------------------------- */
        $defaults = array(
            'default-image'          => '',
            'random-default'         => false,
            'width'                  => 0,
            'height'                 => 0,
            'flex-height'            => false,
            'flex-width'             => false,
            'default-text-color'     => '',
            'header-text'            => true,
            'uploads'                => true,
            'wp-head-callback'       => '',
            'admin-head-callback'    => '',
            'admin-preview-callback' => '',
        );
        
        add_theme_support( 'custom-header', $defaults );

        /* Setup the post thumbnail size for the theme.
        ------------------------------------------------------------------------------ */

        set_post_thumbnail_size( 1140, 757, true ); //this is wide enough for 12 cols of the bootstrap grid system
        /* add custom image sizes */
        add_image_size( 'themeora-thumbnail-span-2', 170, 110, true ); //spans 2 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-3', 270, 174, true ); //spans 3 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-4', 370, 239, true ); //spans 4 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-5', 470, 304, true ); //spans 5 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-6', 570, 369, true ); //spans 6 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-7', 670, 434, true ); //spans 7 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-8', 770, 498, true ); //spans 8 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-9', 870, 563, true ); //spans 9 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-10', 970, 628, true ); //spans 10 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-11', 1070, 692, true ); //spans 11 cols of the bootstrap grid
        add_image_size( 'themeora-thumbnail-span-12', 1170, 757, true ); //spans 12 cols of the bootstrap grid
        
        /* portfolio sizes */
        add_image_size( 'themeora-portfolio-span-12', 1170, 1100, true ); //spans 12 cols of the bootstrap grid
        add_image_size( 'themeora-portfolio-span-11', 1170, 1006, true ); //spans 11 cols of the bootstrap grid
        add_image_size( 'themeora-portfolio-span-10', 970, 912, true ); //spans 10 cols of the bootstrap grid
        add_image_size( 'themeora-portfolio-span-9', 870, 818, true ); //spans 9 cols of the bootstrap grid
        add_image_size( 'themeora-portfolio-span-8', 770, 724, true ); //spans 8 cols of the bootstrap grid
        add_image_size( 'themeora-portfolio-span-7', 670, 630, true ); //spans 7 cols of the bootstrap grid
        
        
    }

endif; //themeora_theme_setup

add_action('after_setup_theme', 'themeora_theme_setup');


/* The main init functions
*  register/enqueue theme scripts, nav areas, and widget areas.
------------------------------------------------------------------------------- */
if ( ! function_exists( 'themeora_enqueue_scripts' ) ) :
    function themeora_enqueue_scripts() {
        /* Styles */
        wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css' );
        wp_enqueue_style( 'fontAwesome', get_template_directory_uri() . '/css/font-awesome.min.css' );
        wp_enqueue_style( 'base-style', get_stylesheet_uri() ); //the essential stylesheet required for the theme to be recognised

        /* Scripts */
        wp_enqueue_script( 'modernizer', WP_THEME_URL . '/js/modernizr.custom.min.js', false, null, true);
        wp_enqueue_script( 'retina', WP_THEME_URL . '/js/retina.js', false, null, true);
        wp_enqueue_script( 'bootstrap', WP_THEME_URL . '/js/bootstrap.min.js', array( 'jquery' ), null, true);

        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
        }
        
        // Register the main js file
        wp_enqueue_script( 'custom', WP_THEME_URL . '/js/custom.js', false, null, true );
        
        // Load Default Google fonts
        wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Merriweather:400,300,500,700|open+sans:400' );

    }
endif; // themeora_enqeue_scripts

add_action( 'wp_enqueue_scripts', 'themeora_enqueue_scripts' );

/**
 * Load Default Google fonts for admin
 */
function themeora_admin_fonts( $hook_suffix ) {
    wp_enqueue_style( 'themeora-google-fonts', '//fonts.googleapis.com/css?family=Merriweather:400,300,500,700|open+sans:400' );
    wp_enqueue_style( 'themeora-fontAwesome', get_template_directory_uri() . '/css/font-awesome.min.css' );
}
add_action( 'admin_enqueue_scripts', 'themeora_admin_fonts' );


if ( ! function_exists( 'themeora_widgets_init' ) ) :

    /* The function to register sidebars & widgets
    ------------------------------------------------------------------------------- */

    function themeora_widgets_init() {

        register_sidebar( array(
            'name' => __( 'Blog Sidebar', 'oren' ),
            'id' => 'blog-sidebar',
            'description' => __( 'Default blog sidebar stuff', 'oren' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="">',
            'after_title' => '</h3>',
        ));

        register_sidebar( array(
            'name' => __( 'Page Sidebar', 'oren' ),
            'id' => 'page-sidebar',
            'description' => __( 'Default page sidebar stuff', 'oren' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="">',
            'after_title' => '</h3>',
        ));

        register_sidebar( array(
            'name' => __( 'Footer widget', 'oren' ),
            'id' => 'footer-widget',
            'description' => __( 'This is the widget for the footer', 'oren' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h2 class="">',
            'after_title' => '</h2>',
        )); 
        
        register_sidebar( array(
            'name' => __( 'Portfolio widget', 'oren' ),
            'id' => 'portfolio-widget',
            'description' => __( 'This is the widget for the portfolio item', 'oren' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h2 class="">',
            'after_title' => '</h2>',
        ));
        
        register_sidebar( array(
            'name' => __( 'Contact page sidebar', 'oren' ),
            'id' => 'contact-sidebar',
            'description' => __( 'This is the widget for the sidebar on the contact page', 'oren' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h2 class="">',
            'after_title' => '</h2>',
        ));
    }
endif; //themeora_widgets_init

add_action( 'widgets_init', 'themeora_widgets_init' );


/* ----------------------- end main init function ----------------------------- */


/* Load theme functions
------------------------------------------------------------------------------ */

require 'inc/functions-utility.php'; // Load useful helper functions
require 'inc/functions-templates.php'; // Load any functions specific to template layouts