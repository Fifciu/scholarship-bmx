<?php 
get_header();
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
?>

<header class="full-width-container no-bottom-padding" role="banner">
    <div class="container">
        <div class="col-md-10 col-md-offset-1">
            <h1 class="archive-title no-bottom-margin"><?php printf( __( 'Posts On %s', 'oren' ), single_cat_title( '', false ) ); ?></h1>
            <?php if ( 1 === $paged ) : ?> 
                <?php if ( category_description() ) : // Show an optional category description ?>
                    <div class="category-description"><?php echo category_description(); ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </div><!-- end col-md-10 -->
    </div><!-- end container -->
</header>

<?php
$layout = get_theme_mod('themeora_blog_layout', 'full-width');
?>

<?php if ( have_posts() ) : ?>
    
    <?php get_template_part( 'templates/blog-sidebar' ); ?>
    
<?php endif; ?>

<?php get_footer(); ?>