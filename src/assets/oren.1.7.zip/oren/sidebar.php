<?php 
/* This is the default sidebar used for blog pages */
?>
<!-- start sidebar -->
<aside class="col-md-3 sidebar col-md-offset-1">
    <?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('blog-sidebar') ) ?>
</aside>
<!-- end blog-sidebar -->