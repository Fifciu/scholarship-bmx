<?php 
get_header();
$show_banner = get_theme_mod('themeora_show_blog_header', 'Yes');
?>

<?php if ( $show_banner == 'Yes' ) : ?>
    <header class="full-width-container no-bottom-padding" role="banner">
        <div class="container">
            <div class="col-md-10 col-md-offset-1">
                <h1 class="archive-title no-bottom-margin"><?php
                    if ( is_day() ) :
                            printf( __( 'Posts for %s', 'oren' ), get_the_date() );
                    elseif ( is_month() ) :
                            printf( __( 'Posts for %s', 'oren' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'oren' ) ) );
                    elseif ( is_year() ) :
                            printf( __( 'Posts for %s', 'oren' ), get_the_date( _x( 'Y', 'yearly archives date format', 'oren' ) ) );
                    else :
                            _e( 'Post Archive', 'oren' );
                    endif;
                ?></h1>
            </div><!-- end col-md-10 -->
        </div><!-- end container -->
    </header>
<?php endif; ?>


<?php if ( have_posts() ) : ?>
    
   <?php get_template_part( 'templates/blog-sidebar' ); ?>
    
<?php endif; ?>

<?php get_footer(); ?>