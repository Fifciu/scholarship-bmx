--------------------------------------------------------------------------------
 Licenses:
--------------------------------------------------------------------------------
This theme is licensed under GNU General Public License v2.0

The resources used in this theme are all GPL-compatible:

Twitter Boostrap is licensed under Apache License v2.0
http://twitter.github.com/bootstrap/

Font Awesome is licensed under SIL Open Font License for font and MIT for CSS.
http://fortawesome.github.com/Font-Awesome/

jQuery is licenced as MIT
jquery.org/license

html5 shiv is MIT/GPL2 Licensed

Moderniser is licenced under the MIT licence

Respond.js has a duel MIT/BSD license

Retina.js is licenced under MIT 
https://github.com/imulus/retinajs/blob/master/LICENSE

Masonry is licenced under the MIT licence
http://masonry.desandro.com

Images from unsplash.com are provided under creative commons zero licence
https://unsplash.com/license

Other icons and images are created by Themeora and licensed under GPL.
--------------------------------------------------------------------------------

