<?php 
/* This is the sidebar used on the default page template */
?>
<!-- start sidebar -->
<aside class="col-md-3 sidebar col-md-offset-1">
    <?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('page-sidebar') ) ?>
</aside>
<!-- end blog-sidebar -->